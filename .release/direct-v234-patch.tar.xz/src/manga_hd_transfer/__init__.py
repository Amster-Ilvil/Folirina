
"""Isolated aligned-overlay reveal patch package for Folirina whole-page mode."""
