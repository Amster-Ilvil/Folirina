from __future__ import annotations

import json
import sys
from pathlib import Path

# This runner is launched with PYTHONPATH pointing exclusively at the exact
# v2.3.4 source tree vendored beside this file.
from manga_hd_transfer.config import PipelineConfig
from manga_hd_transfer.models import PagePair
from manga_hd_transfer.pipeline import TransferPipeline, PipelineCancelled


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: run_page.py REQUEST_JSON RESPONSE_JSON", file=sys.stderr)
        return 64
    request_path = Path(sys.argv[1])
    response_path = Path(sys.argv[2])
    request = json.loads(request_path.read_text(encoding="utf-8"))
    cancel_path = Path(str(request.get("cancel_path") or "")) if request.get("cancel_path") else None
    try:
        cfg = PipelineConfig.model_validate(request["config"])
        # The bridge is intentionally Direct-only; never let a serialized stale
        # GUI value route this subprocess into another renderer.
        cfg.transfer.mode = "direct_patch"
        pair = PagePair(**request["pair"])
        pipeline = TransferPipeline(cfg)
        project = pipeline.process_page(
            pair,
            request["page_root"],
            request.get("final_path"),
            page_mark=request.get("page_mark"),
            cancel_cb=(lambda: bool(cancel_path and cancel_path.exists())),
            progress_cb=None,
        )
        response = {"status": "ok", "project": project.to_dict()}
        response_path.write_text(json.dumps(response, ensure_ascii=False), encoding="utf-8")
        return 0
    except PipelineCancelled as exc:
        response_path.write_text(json.dumps({"status": "cancelled", "message": str(exc)}, ensure_ascii=False), encoding="utf-8")
        return 20
    except BaseException as exc:
        import traceback
        response_path.write_text(json.dumps({
            "status": "error",
            "message": str(exc),
            "traceback": traceback.format_exc(),
        }, ensure_ascii=False), encoding="utf-8")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
